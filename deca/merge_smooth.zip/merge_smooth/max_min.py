import glob
import os
from scipy.io import loadmat
import numpy as np
from tqdm import tqdm
lists = glob.glob('./Actor_1/*.mat')

minus1 = []
minus2 = []
minus3 = []
for i in tqdm(lists):
    data = loadmat(i)['pose'][:,:3]
    minus1.append(np.max(data[:,0])-np.min(data[:,0]))
    minus2.append(np.max(data[:,1])-np.min(data[:,1]))
    minus3.append(np.max(data[:,2])-np.min(data[:,2]))

print(np.max(minus1))
print(np.min(minus1))
print('_____________')
print(np.max(minus2))
print(np.min(minus2))
print('_____________')
print(np.max(minus3))
print(np.min(minus3))
print('_____________')